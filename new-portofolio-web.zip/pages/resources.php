<div>
	<p>Saya senang sekali menggunakan sumber daya dan juga tools yang saya dapat dari internet, berikut adalah favorit saya</p>

	<h2 style="margin-top: 1.8rem;font-weight: 700;
margin-bottom: 2rem;"><span style="margin-right: 10px;"><i class="fas fa-brush"></i></span>Color & Backgrounds</h2>
	<ul class="fa-ul resources-list" style="margin-left: 3.5rem">
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span>
			<a href="https://coolors.co/">Coolors</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span>
			<a href="#">WebGradient</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span>
			<a href="#">Pexels</a>
		</li>
	</ul>

	<h2 style="margin-top: 1.8rem;font-weight: 700;
margin-bottom: 2rem;"><span style="margin-right: 10px;"><i class="fas fa-icons"></i></span>Icons</h2>
	<ul class="fa-ul resources-list" style="margin-left: 3.5rem">
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span>
			<a href="#">Font    Awesome</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span>
			<a href="#">WebGradient</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span>
			<a href="#">Pexels</a>
		</li>
	</ul>

	<h2 style="margin-top: 1.8rem;font-weight: 700;
margin-bottom: 2rem;"><span style="margin-right: 10px;"><i class="fas fa-code"></i></span>Code Editor</h2>
	
	<p class="notes"><i><span class="highlight">Sublime Text</span> biasa saya gunakan di laptop, sedangkan untuk code editor berkemampuan tinggi seperti <span class="highlight">VSCode</span> dan <span class="highlight">Visual Studio 2017 Community Edition</span> saya sering pakai di komputer</i></p>

	<h3 style="font-size: 14px;">Extension</h3>
	<ul class="fa-ul resources-list" style="margin-left: 3.5rem">
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">Git</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">PHP Intelephense</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">Eslint</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">Prettier</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">Monokai Theme</a>
		</li>
	</ul>

	<h2 style="margin-top: 1.8rem;font-weight: 700;
margin-bottom: 2rem;"><span style="margin-right: 10px;"><i class="fas fa-terminal"></i></span>Terminal</h2>

	<ul class="fa-ul resources-list" style="margin-left: 3.5rem">
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">Command Prompt (Windows)</a>
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span><a href="#">Terminal XFCE (Linux)</a>
		</li>
	</ul>

	<h2 style="margin-top: 1.8rem;font-weight: 700;
margin-bottom: 2rem;"><span style="margin-right: 10px;"><i class="fas fa-desktop"></i></span>BattleStation</h2>
	
	<h3 style="font-size: 14px;">Laptop</h3>
	<ul class="fa-ul resources-list" style="margin-left: 3.5rem">
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> AMD E2 1.6 Ghz Dual-core
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> 6 GB
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> 240GB SSD
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> AMD Radeon HD6310
		</li>
	</ul>
	<br>
	<h3 style="font-size: 14px;">Komputer</h3>
	<ul class="fa-ul resources-list" style="margin-left: 3.5rem">
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> Intel G4560
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> 8 GB
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> 120GB SSD + 500GB HDD + 500GB HDD
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> NVIDIA GTX 750Ti
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> 1x 24" Samsung 60hz
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> Rexus Battlefire KX1
		</li>
		<li class="fa-li">
			<span class="fa-li"><i class="fa fa-chevron-right"></i></span> Alcatroz Airmouse3
		</li>
	</ul>
</div>