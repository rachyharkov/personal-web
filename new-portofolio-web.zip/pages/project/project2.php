<div class="row">
        <div class="col-sm-9" style="height: auto;">
            <div class="portofolioinfowrapper">
                <h3><a id="projectmoduleproductrec" href="#projectmoduleproductrec"><img src="./assets/images/chain-50.png"></a>Product Recommendation Module for Web <span><img src="./assets/images/Label-sideproject.svg"></span></h3>
                <article>
                    <p>
                        <a href="#"><img src="./assets/images/madewith-vanillajs.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img src="./assets/images/AJAX-Technology.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img src="./assets/images/coverage-92-green.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img src="./assets/images/Framework-MaterializeCSS-EB7077.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img src="./assets/images/status-maintained.svg" style="border-radius: 5px;"></a>
                    </p>
                    <p>
                    Saya pernah kedapatan ide untuk membuat sebuah kuesioner berbasis pilihan yang dapat menyarankan produk mana yang cocok bagi mereka, kasus ini saya dapatkan dari usaha Troli Ayah yang calon pembelinya selalu bingung dalam memilih troli yang cocok bagi mereka, karena ayah saya kewalahan untuk membalas melalui berbagai platform komunikasi (seperti WA, FB Messenger, OLX, dll) serta menyarankan mana troli yang cocok berdasarkan kebutuhan mereka, saya mengumpulkan data-data pertanyaan pembeli setiap beliau dihubungi calon pembeli yang selanjutnya saya rangkum menjadi sebuah module/project kecil yang dapat dipasang pada web Akuradz Troli berupa kuesioner dengan opsi jawaban yang dapat dipilih berdasarkan keadaan calon pembeli, dengan adanya module ini diharapkan dapat meringankan Ayah saya dalam menjalankan aktivitas berjualan trolinya. Module ini dibangun dengan menggunakan Vanilla Javascript, tidak menutup kemungkinan project ini juga dapat dibuat dengan JQuery karena sama-sama menggunakan teknologi AJAX sehingga dapat merespon pertanyaan dari pengunjung web dengan cepat. 
                    </p>
                    <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Demo</h5>
                    <p>
                        Karena ini merupakan module, berarti juga dapat disebut sebagai <b>fitur/element</b> karena awalnya website Akuradz Troli tidak memiliki fitur ini diwebsitenya, sehingga fitur ini dapat diimplementasikan di berbagai website yang menayangan sebuah konten/produk. Ingin melihat bagaimana module ini bekerja? silahkan cek pada link berikut : <br>
                        <ul><li><a href="#">Demo</a></li></ul>
                        Merasa cocok dengan website yang anda miliki? silahkan email saya untuk komunikasi lebih lanjut.                    
                </article>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="portofolioinfowrapper side-right-info">
                <h5>Product Recommendation - Web Module Element</h5>
                
                <a href="productrecommendationmoduleweb.php" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: dodgerblue;" role="button"><i class="fas fa-fw fa-eye"></i></a>
                <a href="https://github.com/rachyharkov" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: #24292E;" role="button"><i class="fab fa-fw fa-github"></i></a>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="coming_soon.php" target="_blank" class="btn btn-md button-side-ri disabled" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button" aria-disabled="true"><i class="fas fa-fw fa-book"></i></a>
                </span>
                <a href="https://trakteer.id/rachmadnh" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
            </div>
        </div>
    </div>