<div class="row">
        <div class="col-sm-9" style="height: auto;">
            <div class="portofolioinfowrapper">
                <h3><a id="projectaplikasipenjualansurat" href="#projectaplikasipenjualansurat"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Aplikasi Penjualan Dinamis + Generate Surat Otomatis <span><img loading=”lazy” src="./assets/images/Label-BusinessPartnerProject.svg"></span></h3>
                <article>
                    <p>
                        <a href="#"><img loading=”lazy” src="./assets/images/Label-SQLServer.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Made With-Visual Basic-blue.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/status-maintained.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/coverage-86-yellowgreen.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Dynamic-CMS.svg" style="border-radius: 5px;"></a>
                    </p>
                    <p>
                        Pembuatan Aplikasi Desktop ini dilatar belakangi dengan aktivitas ayah saya (Menjual Troli) yang mana tidak jauh dari membuat hingga mengelola surat, adapun surat yang sering dijumpai adalah Surat Penawaran, Faktur, Surat Jalan, Invoice, dan Kwitansi. Kadang beliau meng-arsipkan banyak ke-5 jenis surat tersebut hingga etalase yang biasa dipakai untuk menyimpan baju penuh dengan surat-surat tersebut. Berdasarkan studi kasus tersebut, saya terpikirkan untuk menjadikan kasus tersebut sebagai topik laporan Matakuliah Analisis dan Perancangan Sistem Informasi yang dikerjakan secara berkelompok. Fungsi utama aplikasi ini adalah dapat menyimpan data penjualan hingga melakukan generate surat Penawaran, Faktur, Surat Jalan, Invoice, dan Kwitansi secara dinamis berdasarkan produk yang diinput. Maka dari itu terciptalah aplikasi Desktop ini. Sebenarnya pembuatan Aplikasi Desktop di Matakuliah ini bersifat opsional, tapi tidak salah jika saya mencoba meng-implementasikan project nyatanya.
                    </p>
                    <p>
                        Aplikasi Desktop ini terkadang masih digunakan oleh ayah saya, beberapa sudah ada yang minat pada aplikasi ini
                    </p>
                    <p>
                        Aplikasi ini dibangun menggunakan Visual Basic dengan .NET sebagai frameworknya, untuk database pada project ini bisa menggunakan SQL Server 2008 R2 sampai 2019. Pada project ini juga disematkan Bunifu UI Framework.
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Screenshot</h5>
                    <p>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-login.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-demo.gif"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-trxlist.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-trx.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-reportlist.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-addjadwal.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-kalender.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss4-editinformasiusaha.jpg"><br>
                        
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Dokumen/File Pendukung</h5>
                    <p>
                        Project ini memiliki dokumen pendukung dalam pembuatannya untuk memperjelas pengerjaan pembuatan aplikasi ini, adapun yang diperlukan hingga tugas ini selesai adalah sebagai berikut
                        <ul>
                            <li><a href="#">Flowmap Diagram Proses</a></li>
                            <li><a href="#">Use Case</a></li>
                            <li><a href="#">Activity Diagram</a></li>
                            <li><a href="#">Class Diagram </a></li>
                            <li><a href="#">Entity Relationship Diagram (ERD)</a></li>
                            <li><a href="#">Laporan Tugas Matakuliah Analisis dan Perancangan Sistem Informasi.docx</a></li>
                        </ul>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Demo</h5>
                    <p>
                        Project ini tidak dapat dipublish ke khalayak umum dikarenakan banyaknya dependensi yang harus direnovasi dan diupgrade, seperti Crystal Report, perlu kalian ketahui bahwa Crystal Report telah usang dan saat ini saya sedang berusaha meluangkan waktu saya untuk mengintegrasikan laporannya ke Report bawaan (bukan third-party) sekaligus memperbaiki bug yang masih bersarang pada proses bisnisnya. Jika kalian penasaran dengan status/keadaan project yang saya bangun ini silahkan sampaikan melalui email ^_^. 
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Kontribusi</h5>
                    <p>
                        Anda memiliki ide dan ingin ikut mengembangkan project ini lebih lanjut? (seperti untuk keperluan komersial, membantu menyempurnakan dan lain-lain), silahkan email saya dengan subject nama project yang ingin anda bicarakan. <br>
                        <br>
                        Saya membuka donasi bagi yang ingin melakukannya :)
                        <ul>
                            <li><a href="https://trakteer.id/rachmadnh">Trakteer</a></li>
                        </ul>
                </article>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="portofolioinfowrapper side-right-info">
                <h5>Aplikasi Penjualan Dinamis - Desktop App</h5>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: dodgerblue;" role="button" aria-disabled="true"><i class="fas fa-fw fa-eye"></i></a>
                </span>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: #24292E;" role="button" aria-disabled="true"><i class="fab fa-fw fa-github"></i></a>
                </span>
                <a href="/coming_soon.php" target="_blank" class="btn btn-md button-side-ri" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-book"></i></a>
                <a href="https://trakteer.id/rachmadnh" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
            </div>
        </div>
    </div>