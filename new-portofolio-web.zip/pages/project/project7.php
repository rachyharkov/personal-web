<div class="row">
        <div class="col-sm-9" style="height: auto;">
            <div class="portofolioinfowrapper">
                <h3><a id="akuradztroliweb" href="#akuradztroliweb"><img loading=”lazy” src="./assets/images/chain-50.png"></a>CAT XHilang - Test Kecermatan Angka, Huruf, dan Simbol Hilang Berbasis Web <span><img loading=”lazy” src="./assets/images/Label-BusinessPartnerProject.svg"></span></h3>
                <article>
                    <p>
                        <a href="#"><img loading=”lazy” src="./assets/images/madewith-vanillajs.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/AJAX-Technology.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/status-maintained.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/coverage-92-green.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/label-frameworkbs.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/label-codeigniter.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Dynamic-CMS.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Database-MySQL.svg" style="border-radius: 5px;"></a>
                    </p>
                        
                    <p>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss7-login.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss7-entertoken.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss7-menuutama.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss7-editsoal.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss7-pesertatest.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss7-pesertatestjeda.jpg"><br>
                    </p>
                    <p>
                        Sebuah Lembaga Belajar melatih/membina/mendidik calon khusus pendaftar tes seleksi anggota POLRI agar siap dalam mengikuti seleksi penerimaan anggota POLRI kedepannya bagi pendaftar yaitu Study Concepts Learning Center berupaya untuk men-digitalisasikan sebuah test assesment yang selama masih menggunakan cara konvensional yaitu <b>Test Angka, Huruf dan Simbol Hilang</b>.
                    </p>

                    <p>
                        Nantinya peserta test akan bisa memilih jawaban yang disediakan untuk dipilih hingga 1 kolom selesai dengan total 30 soal/kolom nya (total 10 kolom pada masing-masing jenis soal yaitu Soal Angka, Huruf dan Simbol). Per-kolomnya diberi waktu hingga 1 menit (sebenarnya ada juga yang 2 menit), jika tidak dapat menyelesaikan soal kolom kurang dari waktu yang ditentukan, maka akan berpindah kolom secara otomatis, aplikasi ini sudah sangat persis seperti cara konvensional pada umumnya, hanya saja sebagai peserta tinggal menggerakan mouse (tidak perlu pulpen, kertas, dan hal merepotkan lainnya), bahkan web application ini bisa diakses secara mobile.
                    </p>

                    <p>
                        Project ini sebenarnya merupakan bentuk kerja sama dengan seseorang untuk tujuan melengkapi modul project CAT Polri yaitu request tambahan seperti yang saya sebutkan diatas, dikarenakan project module ini tidak ke handle, saya direkrut untuk membantunya dan saya terima kerjaan tersebut (Saya akan inget dengan kebaikan orang yang memberi project ini ke saya, karena project ini memotivasi saya untuk terus eksplorasi jauh diinternet, semoga sehat selalu bang Ramdan hehe).
                    </p>

                    <p>
                        Web Application CAT XHilang ini memiliki fitur sebagai berikut
                        <ol>
                            <li style="list-style: circle;">Login System (Admin, dan Peserta yang disertai dengan token login system)</li>
                            <li style="list-style: circle;">Menu yang simple</li>
                            <li style="list-style: circle;">[Admin] Kelola Daftar Peserta (Menambahkan, Menghapus, Edit) </li>
                            <li style="list-style: circle;">[Admin] Laporan dan Dashboard informatif berisi siapa saja yang sedang test, yang sudah mengerjakan, dan yang belum mengerjakan, daftar token yang siap untuk diinput peserta, bahkan ada top 10 peserta terbaik dengan nilai terbaik</li>
                            <li style="list-style: circle;">[Admin] Print Laporan nilai peserta ke Excel</li>
                            <li style="list-style: circle;">[Admin] Kelola Soal Angka, Huruf dan Simbol</li>
                            <li style="list-style: circle;">[Admin] Melakukan import soal dari excel</li>
                            <li style="list-style: circle;">[Peserta] Sistem Jeda untuk tiap jenis soal dan menampilkan nilai pada masing2 jenis soal (tiap jenis soal ada 300 soal)</li>
                            <li style="list-style: circle;">[Peserta] Tampilan yang nyaman dilihat</li>
                            <li style="list-style: circle;">[Peserta] Validasi ketat saat melakukan test</li>
                        </ol>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Logic Diagram</h5>
                    <p>
                        Berikut adalah logic diagram pada aplikasi ini :<br>
                        <ul>
                            <li><a href="#">Flowchart</a></li>
                            <li><a href="#">UML Database</a></li>
                        </ul>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Link</h5>
                    <p>
                        Sayang sekali project ini tidak dapat ditest oleh banyak orang dikarenakan sudah diimplementasikan ke website berikut :<br>
                        <ul>
                            <li><a href="https://study-concepts.com/cat">Website Study Concept</a></li>
                        </ul>
                        Yang mana mengharuskan kalian untuk daftar ke lembaga tersebut, tapi jangan khawatir, saya siap mempresentasikan sebuah demo jika anda mau.

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Ingin dikembangkan lebih lanjut?</h5>
                    <p>
                        Anda memiliki ide untuk mengembangkan project ini lebih lanjut? (seperti untuk keperluan komersial dan lain-lain), silahkan email saya dengan subject nama project yang ingin anda bicarakan ^_^ di rachmadnurhayat@gmail.com<br>
                        <br>
                        Sebenarnya web application ini masih belum sempurna tapi dari segi fungsionalitas sudah 100% bekerja dan 'mungkin' belum sepenuhnya bagus, bagi yang ingin tahu lebih lanjut bisa email saya dan bagi yang ingin mengirim donasi, silahkan klik dibawah ini
                        <ul>
                            <li><a href="https://trakteer.id/rachmadnh">Trakteer</a></li>
                        </ul>
                </article>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="portofolioinfowrapper side-right-info">
                <h5>CAT XHilang</h5>
                
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: dodgerblue;" role="button" aria-disabled="true"><i class="fas fa-fw fa-eye"></i></a>
                </span>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: #24292E;" role="button" aria-disabled="true"><i class="fab fa-fw fa-github"></i></a>
                </span>
                
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-md button-side-ri disabled" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-book" aria-disabled="true"></i></a>
                </span>
                <a href="https://trakteer.id/rachmadnh" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
            </div>
        </div>
    </div>