<div class="row">
    <div class="col-sm-9" style="height: auto;">
        <div class="portofolioinfowrapper">
            <h6>Readme</h6>
            <h3><a id="applapanganfutsal" href="#applapanganfutsal"><img src="./assets/images/chain-50.png"></a>Aplikasi Lapangan Futsal <span><img src="./assets/images/label-collegeproject.svg"></span></h3>
            <article>
                <p>
                    <a href="#"><img src="./assets/images/cont-labels.svg" style="border-radius: 5px;"></a> 
                    <a href="#"><img src="./assets/images/Made With-Visual Basic-blue.svg" style="border-radius: 5px;"></a> 
                    <a href="#"><img src="./assets/images/coverage-90-green.svg" style="border-radius: 5px;"></a>
                    <a href="#"><img src="./assets/images/Label-SQLServer.svg" style="border-radius: 5px;"></a> 
                </p>
                <p>
                Tujuan dari dibuatnya aplikasi ini adalah untuk memenuhi tugas project Matakuliah Pemrograman 2 yang dilaksanakan di Kampus, Aplikasi ini bermanfaat bagi para pelaku usaha yang mempunyai jasa sewa lapangan futsal (entah itu 1 atau lebih lapangan) untuk memantau waktu serta detail lainnya yang tentunya bermanfaat bagi pemiliki usaha sewa lapangan futsal. Dibangun dengan bahasa Visual Basic dengan .NET sebagai frameworknya (VB NET), serta ter-integrasi dengan Database SQL Server (mulai dari 2008 R2 sampai 2019) yang dijalankan secara lokal, sehingga dapat meringankan beban komputer anda.
                </p>
                <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Fitur</h5>

                <p>
                    <ol>
                        <li style="list-style: circle;">Login System (Admin, Pengelola, Pengelola Sementara)</li>
                        <li style="list-style: circle;">Dashboard Utama yang Informatif</li>
                        <li style="list-style: circle;">Informasi Lapangan yang sedang di sewa lebih detail </li>
                        <li style="list-style: circle;">Kalkulasi yang Akurat penghitungan harga dengan kebutuhan sewa</li>
                        <li style="list-style: circle;">Laporan Pendapatan Harian, Mingguan, Bulanan, dan Master (Menggunakan "Crystal Report")</li>
                        <li style="list-style: circle;">Histori Penggunaan Lapangan berdasarkan Transaksi</li>
                        <li style="list-style: circle;">Aplikasi yang dapat terintegrasi dengan Alarm (mulai dan selesai)</li>
                        <li style="list-style: circle;">Sistem Member dan Non-Member bagi penyewa Lapangan</li>
                        <li style="list-style: circle;">Cetak Struk</li>
                        <li style="list-style: circle;">Kustomisasi Struk</li>
                        <li style="list-style: circle;">Aplikasi yang dapat dipersonalisasikan Tampilannya</li>
                        <li style="list-style: circle;">Sistem Manajemen Akun serta Hak Akses</li>
                        <li style="list-style: circle;">Kustomisasi Harga Per-jam yang dinamis</li>
                        <li style="list-style: circle;">Mode Bersih pada lapangan, mencegah lapangan tidak dapat digunakan saat transaksi</li>
                        <li style="list-style: circle;">Dokumentasi Lengkap (coming soon...)</li>
                        <li style="list-style: circle;">Dan masih banyak lagi...</li>
        
    
            
                <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Screenshot</h5>
                <p style="text-align: center;">
                    <div class="img-fluid loading">
                        <img class="lazyload" style="width: 100%;" src="./assets/images/project-list/ss1-login.jpg">
                    </div>
                    <div class="img-fluid loading">
                        <img class="lazyload" style="width: 100%;" src="./assets/images/project-list/ss1-dashboard.jpg">
                    </div>
                    <div class="img-fluid loading">
                        <img class="lazyload" style="width: 100%;" src="./assets/images/project-list/ss1-lapangan.jpg">
                    </div>
                    <div class="img-fluid loading">
                        <img class="lazyload" style="width: 100%;" src="./assets/images/project-list/ss1-pay.jpg">
                    </div>
                    <div class="img-fluid loading">
                        <img class="lazyload" style="width: 100%;" src="./assets/images/project-list/ss1-strukcustomize.jpg">
                    </div>
                

                <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Dokumen/File Pendukung</h5>
                <p>
                    Project ini memiliki dokumen pendukung dalam pembuatannya untuk memperjelas pengerjaan pembuatan aplikasi ini, adapun yang diperlukan hingga tugas ini selesai adalah sebagai berikut
                    <ul>
                        <li><a href="#">Laporan Project.docx</a></li>
                        <li><a href="#">Laporan Kemajuan Project.docx</a></li>
                        <li><a href="./assets/images/project-list/ss1-usecase.png">Use Case.png</a></li>
                        <li><a href="#">Activity Diagram.png</a></li>
                        <li><a href="#">ERD.png</a></li>
                    </ul>
                

                <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Kontribusi</h5>
                <p>
                    Walaupun saya lulus di Matakuliah Pemrograman 2 dengan membawa project ini, saya juga akan berencana membuatnya sebagai open-source untuk memudahkan kalian para kakak/adik mahasiswa/mahasiswi dalam mengerjakan project dengan tema yang sama plus membantu saya mengembangkan project ini agar lebih sempurna dari yang sekarang, tujuan utamanya adalah untuk mencapai fungsi aplikasi yang 100% memenuhi target keinginan pemilik futsal.<br>
                    <a href="#">Repository Link (Github)</a><br>
                    *<b>Perhatian :</b> Saya mohon untuk jangan jadikan project ini sebagai jalan pintas kalian dalam menyelesaikan project dengan tema yang sama yaitu Aplikasi Lapangan Futsal karena "it ain't cool!". 
                

                <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Jejak Versi</h5>
                <p>
                    Untuk jejak versi dapat di cek pada <a href="#">link ini</a>.
                </p>

                <h5><a href="#"><img src="./assets/images/chain-50.png"></a>Ingin dikembangkan lebih lanjut?</h5>
                <p>
                    Anda memiliki ide untuk mengembangkan project ini lebih lanjut? (seperti untuk keperluan komersial dan lain-lain), silahkan email saya dengan subject nama project yang ingin anda bicarakan ^_^. <br>
                    <br>
                    Tertarik untuk donasi?
                    <ul>
                        <li><a href="https://trakteer.id/rachmadnh">Trakteer</a></li>
                    </ul>

            </article>
            <br>
        </div>
    </div>
    <div class="col-sm-3">
        <div class="portofolioinfowrapper side-right-info">
            <h5>Aplikasi Lapangan Futsal</h5>
            <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: dodgerblue;" role="button" aria-disabled="true"><i class="fas fa-fw fa-eye"></i></a>
            </span>
            
            <a href="https://github.com/rachyharkov" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: #24292E;" role="button"><i class="fab fa-fw fa-github"></i></a>
            <a href="#" target="_blank" class="btn btn-md button-side-ri" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-book"></i></a>
            <a href="#" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
        </div>
    </div>
</div>