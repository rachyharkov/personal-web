<div class="row">
        <div class="col-sm-9" style="height: auto;">
            <div class="portofolioinfowrapper">
                <h3><a id="projecttokosoftware" href="#projecttokosoftware"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Web CMS Jualan Software <span><img loading=”lazy” src="./assets/images/label-collegeproject.svg"></span></h3>
                <article>
                    <p>
                        <a href="#"><img loading=”lazy” src="./assets/images/label-codeigniter.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Dynamic-CMS.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Database-MySQL.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/coverage-86-yellowgreen.svg" style="border-radius: 5px;"></a>
                    </p>
                    <p>
                    Project ini merupakan syarat untuk memenuhi kelulusan matakuliah Pemrograman Web 2, project ini dibangun menggunakan Template SB Admin, Bahasa PHP, Codeigniter 3 sebagai Framework PHP-nya, Vanilla Javascript dan JQuery untuk memfungsikan beberapa fitur, untuk Front-End tidak saya kembangkan (dan hanya sebatas bisa menginput pesanan) karena di matakuliah ini kami difokuskan pada Back-End nya.
                    </p>
                    <p>
                        Karena ide saya tentang jual software, maka saya memberikan CMS ini dengan nama TS Admin Panel (TS kepanjangan dari Toko Software).
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Screenshot</h5>
                    <p>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss3-dashboard.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss3-daftartransaksi.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss3-daftarsoftware.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss3-logactivity.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss3-pengaturan.jpg"><br>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss3-transaksimasuk.jpg"><br>
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Dokumen/File Pendukung</h5>
                    <p>
                        Project ini memiliki dokumen pendukung dalam pembuatannya untuk memperjelas pengerjaan pembuatan aplikasi ini, adapun yang diperlukan hingga tugas ini selesai adalah sebagai berikut
                        <ul>
                            <li><a href="#">Entity Relationship Diagram</a></li>
                            <li><a href="#">Sitemap</a></li>
                            <li><a href="#">Laporan Tugas Besar Pemrograman Web 2.docx</a></li>
                        </ul>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Demo</h5>
                    <p>
                        Project ini dapat diakses pada repository github berikut
                        <ul>
                            <li><a href="#">CMS Tokosoftware</a></li>
                        </ul>
                        *<b>Perhatian :</b> Saya mohon untuk jangan jadikan project ini sebagai jalan pintas kalian dalam menyelesaikan project dengan tema yang sama yaitu Web Application Penjualan Software karena "it ain't cool!". 

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Jejak Versi</h5>
                    <p>
                        Untuk jejak versi dapat di cek pada <a href="#">link ini</a>.
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Ingin dikembangkan lebih lanjut?</h5>
                    <p>
                        Anda memiliki ide untuk mengembangkan project ini lebih lanjut? (seperti untuk keperluan komersial dan lain-lain), silahkan email saya dengan subject nama project yang ingin anda bicarakan ^_^. <br>
                        <br>
                        Tertarik untuk donasi?
                        <ul>
                            <li><a href="https://trakteer.id/rachmadnh">Trakteer</a></li>
                        </ul>
                </article>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="portofolioinfowrapper side-right-info">
                <h5>Toko Software - Web App</h5>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: dodgerblue;" role="button" aria-disabled="true"><i class="fas fa-fw fa-eye"></i></a>
                </span>
                <a href="https://github.com/rachyharkov/" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: #24292E;" role="button"><i class="fab fa-fw fa-github"></i></a>
                <a href="coming_soon.php" target="_blank" class="btn btn-md button-side-ri" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-book"></i></a>
                <a href="https://trakteer.id/rachmadnh" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
            </div>
        </div>
    </div>