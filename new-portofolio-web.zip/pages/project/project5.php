<div class="row">
        <div class="col-sm-9" style="height: auto;">
            <div class="portofolioinfowrapper">
                <h3><a id="indihomemarketingweb" href="#indihomemarketingweb"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Website Promosi Marketing Indihome Bekasi <span><img loading=”lazy” src="./assets/images/Label-BusinessPartnerProject.svg"></span></h3>
                <article>
                    <p>
                        <a href="#"><img loading=”lazy” src="./assets/images/madewith-vanillajs.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/HTML5-CSS3-3576BE.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/label-frameworkbs.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/release-date-juny-2020-orange.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/website-up-brightgreen.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/server-up-brightgreen.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/domain-up-brightgreen.svg" style="border-radius: 5px;"></a>
                    </p>
                    <p>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss5-landingpage-old.jpg"><br>
                    </p>
                    <p>
                        Website ini untuk menunjang kebutuhan promosi pemasangan internet fiber berkecepatan tinggi Indihome yang dilakukan oleh Marketing Indihome daerah Bekasi, website ini juga menjadi jembatan komunikasi antara calon pelanggan dengan Marketing yaitu dengan mengimplementasikan formulir pendaftaran yang ter-integrasi dengan whatsapp API langsung sehingga calon pelanggan tidak perlu memasukan nomor WhatsApp marketing Indihome Bekasi ini secara manual.
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Link</h5>
                    <p>
                        Website ini dapat diakses pada link berikut :<br>
                        <ul>
                            <li><a href="https://indihomebekasipromo.com">Indihome Bekasi Promo</a></li>
                            <li><a href="https://infopasangbaru.com">Info Pasang Baru (New)</a></li>
                        </ul>

                </article>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="portofolioinfowrapper side-right-info">
                <h5>Indihome Bekasi - Web</h5>

                <a href="https://indihomebekasipromo.com" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: dodgerblue;" role="button"><i class="fas fa-fw fa-eye"></i></a>
                <a href="https://infopasangbaru.com" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: dodgerblue;" role="button"><i class="fas fa-fw fa-eye"></i></a>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: #24292E;" role="button" aria-disabled="true"><i class="fab fa-fw fa-github"></i></a>
                </span>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-md button-side-ri disabled" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button" aria-disabled="true"><i class="fas fa-fw fa-book"></i></a>
                </span>
                <a href="https://trakteer.id/rachmadnh" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
            </div>
        </div>
    </div>