<div class="row">
        <div class="col-sm-9" style="height: auto;">
            <div class="portofolioinfowrapper">
                <h3><a id="akuradztroliweb" href="#akuradztroliweb"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Website Promosi Alat Angkut Troli - Akuradz Troli <span><img loading=”lazy” src="./assets/images/Label-BusinessPartnerProject.svg"></span></h3>
                <article>
                    <p>
                        <a href="#"><img loading=”lazy” src="./assets/images/madewith-vanillajs.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/HTML5-CSS3-3576BE.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/Framework-MaterializeCSS-EB7077.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/PWA-Technology-green.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/release-date-july-2020-orange.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/status-maintained.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/server-down-red.svg" style="border-radius: 5px;"></a>
                        <a href="#"><img loading=”lazy” src="./assets/images/domain-up-brightgreen.svg" style="border-radius: 5px;"></a>
                        
                    </p>
                    <p>
                        <img loading=”lazy” class="img-fluid" src="./assets/images/project-list/ss6-landingpage.jpg"><br>
                    </p>
                    <p>
                        Dikarenakan makin tingginya permintaan informasi alat angkut barang berupa troli pada usaha jualan Ayah saya, maka saya membuatkan sebuah website dengan teknologi PWA (Progressive Web App) untuk membantu Ayah saya dalam melayani permintaan informasi oleh para calon customer, dengan adanya website ini, diharapkan aktivitas membalas pesan menjadi sedikit ringan (terutama yang topik pembahasannya tentang macam produk) karena semua informasi troli yang meliputi spesifikasi, foto tampilan, dan sebagainya sudah tertera pada website tersebut. Lalu Ayah saya hanya tinggal fokus membicarakan pemesanan yang akan segera terjadi kepada calon pelanggannya.
                    </p>

                    <p>
                        Teknologi PWA menjadi pilihan saya mengingat rata-rata para pengakses website/internet cenderung tidak ingin menunggu lama saat mereka mengakses sebuah website. Untuk pembahasan lebih lanjut mengenai teknologi PWA bisa anda lihat di artikel saya berikut ini <a href="www.google.com">(Pentingnya Progressive Web App untuk Kebutuhan Bisnis)</a>. 
                    </p>

                    <h5><a href="#"><img loading=”lazy” src="./assets/images/chain-50.png"></a>Link</h5>
                    <p>
                        Website ini dapat diakses pada link berikut :<br>
                        <ul>
                            <li><a href="https://akuradz-troli.com">Akuradz Troli</a></li>
                        </ul>
                        <b>*Catatan:</b> Website ini sedang dalam keadaan down karena website ini berpindah server, dalam waktu dekat saya akan mencari hosting yang cocok untuk menampung website ini, mohon maaf atas ketidaknyamanannya.
                </article>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="portofolioinfowrapper side-right-info">
                <h5>Akuradz Troli - Web</h5>
                
                <a href="https://akuradz-troli.com" target="_blank" class="btn btn-secondary btn-md button-side-ri" style="background-color: dodgerblue;" role="button" aria-disabled="true"><i class="fas fa-fw fa-eye"></i></a>
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-secondary btn-md button-side-ri disabled" style="background-color: #24292E;" role="button" aria-disabled="true"><i class="fab fa-fw fa-github"></i></a>
                </span>
                
                <span class="button-side-ri" tabindex="0" data-bs-toggle="tooltip" title="Tidak tersedia untuk project ini">
                    <a href="#" target="_blank" class="btn btn-md button-side-ri disabled" style="background-color:#6d6d6d; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-book" aria-disabled="true"></i></a>
                </span>
                <a href="https://trakteer.id/rachmadnh" target="_blank" class="btn btn-md button-side-ri" style="background-color:#BE1E2D; color: rgb(233, 233, 233);" role="button"><i class="fas fa-fw fa-hand-holding-usd"></i></a>    
            </div>
        </div>
    </div>