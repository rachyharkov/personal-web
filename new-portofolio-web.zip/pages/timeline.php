<div style="display: flex;">
	<ul class="timeline-ul">
		<li class="animated fadeInDown">
			<div>
				1998
				<article style="margin-left: auto;
padding-bottom: 2em;
text-align: right;">🐣 Lahir</article>
			</div>

		</li>
		<li class="animated fadeInDown">
			<div>
				2017
				<article style="margin-left: auto;
padding-bottom: 2em;
text-align: right;">📚 Sekolah Menengah Kejuruan<br>Bina Karya Mandiri 1, Bekasi</article>
			</div>
		</li>
		<li class="animated fadeInDown">
			<div>
				2017
				<article style="margin-left: auto;
padding-bottom: 2em;
text-align: right;">💼 Fiber Optic Technician<br>PT. Quantum Nusatama, Jakarta</article>
			</div>
		</li>
		<li class="animated fadeInDown">
			<div>
				2021
				<article style="margin-left: auto;
padding-bottom: 2em;
text-align: right;">💼 Junior Officer IT Business<br>PT. Rekayasa Industri, Jakarta</article>
			</div>
		</li>
		<li class="animated fadeInDown">
			<div>
				Sekarang
				<article style="margin-left: auto;
padding-bottom: 2em;
text-align: right;">🧑‍🎓 S1 Teknik Informatika<br>Universitas Bina Insani, Bekasi</article>
			</div>

		</li>
		<li class="animated fadeInDown">
			<div>
				Sekarang
				<article style="margin-left: auto;
padding-bottom: 2em;
text-align: right;">💼 Web Developer<br>Freelancer, Anywhere City</article>
			</div>

		</li>
	</ul>
</div>